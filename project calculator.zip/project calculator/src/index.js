const display = document.getElementById("num-box");

let currentInput = "0";
let operator = null;
let previousInput = null;
let shouldResetDisplay = false;

function updateDisplay() {
    display.value = currentInput;
}

function appendNumber(number) {
    if (currentInput === "0" || shouldResetDisplay) {
        currentInput = number;
        shouldResetDisplay = false;
    } else {
        currentInput += number;
    }
    updateDisplay();
}

function chooseOperator(op) {
    if (operator && !shouldResetDisplay) {
        calculate();
    }
    operator = op;
    previousInput = currentInput;
    shouldResetDisplay = true;
}

function calculate() {
    if (!operator || previousInput === null) return;

    const prev = parseFloat(previousInput);
    const curr = parseFloat(currentInput);

    let result;
    switch (operator) {
        case "+":
            result = prev + curr;
            break;
        case "-":
            result = prev - curr;
            break;
        case "x":
        case "*":
            result = prev * curr;
            break;
        case "÷":
        case "/":
            if (curr === 0) {
                alert("Cannot divide by zero");
                clear();
                return;
            }
            result = prev / curr;
            break;
        case "%":
            result = prev % curr;
            break;
        default:
            return;
    }

    currentInput = result.toString();
    operator = null;
    previousInput = null;
    shouldResetDisplay = true;
    updateDisplay();
}

function clear() {
    currentInput = "0";
    previousInput = null;
    operator = null;
    shouldResetDisplay = false;
    updateDisplay();
}

function toggleSign() {
    currentInput = currentInput.startsWith("-") ? currentInput.slice(1) : "-" + currentInput;
    updateDisplay();
}

function appendDot() {
    if (shouldResetDisplay) {
        currentInput = "0";
        shouldResetDisplay = false;
    }
    if (!currentInput.includes(".")) {
        currentInput += ".";
    }
    updateDisplay();
}

function handleInput(input) {
    if (!isNaN(input)) {
        appendNumber(input);
    } else if (input === "C" || input === "c") {
        clear();
    } else if (input === "=" || input === "Enter") {
        calculate();
    } else if (input === "+/-") {
        toggleSign();
    } else if (input === ".") {
        appendDot();
    } else if (["+","-","*","x","/","÷","%"].includes(input)) {
        chooseOperator(input);
    }
}

document.addEventListener("click", function(event) {
    const target = event.target;

    if (target.tagName !== "BUTTON") return;

    const buttonValue = target.innerHTML;

    handleInput(buttonValue);
});

// Event listener for keyboard inputs
document.addEventListener("keydown", function(event) {
    const key = event.key;

    if (key === "Escape") {
        clear();
    } else if (key === "Backspace") {
        currentInput = currentInput.slice(0, -1) || "0";
        updateDisplay();
    } else {
        handleInput(key);
    }
});

updateDisplay();
